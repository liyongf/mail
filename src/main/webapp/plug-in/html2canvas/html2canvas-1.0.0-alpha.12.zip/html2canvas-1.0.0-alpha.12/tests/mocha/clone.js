document.querySelector('#block').className += 'class';
